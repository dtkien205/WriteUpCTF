(function () {
  var f = document.querySelector('form[action="/login"]');
  if (!f) return;
  f.addEventListener("submit", function () {
    try {
      console.log("[portal] issuing legacy AES-CBC session token");
    } catch (e) {}
  });
})();
