import os
import time

from flask import (
    Flask, request, redirect, render_template, make_response, abort,
)

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from base64 import b64encode, b64decode
from binascii import Error as B64Error

SESSION_KEY = bytes.fromhex(os.environ["SESSION_KEY"])

TOKEN_EXP = "1798675200"

USERS = {
}

ROLES = {
}

app = Flask(__name__)

def build_plaintext(user, role):
    return (
        "brand=ShopBroken"
        ";role=" + role +
        ";uid=1001;exp=" + TOKEN_EXP +
        ";u=" + user
    ).encode()


def seal(user, role):
    iv = os.urandom(16)
    ct = AES.new(SESSION_KEY, AES.MODE_CBC, iv).encrypt(
        pad(build_plaintext(user, role), 16)
    )
    return b64encode(iv + ct).decode()


def parse_fields(data):
    fields = {}
    for seg in data.split(b";"):
        if b"=" not in seg:
            continue
        k, v = seg.split(b"=", 1)
        fields[k.decode("latin-1")] = v.decode("latin-1")
    return fields


def open_session():
    raw = request.cookies.get("session")
    if not raw:
        return None
    try:
        blob = b64decode(raw)
    except (B64Error, ValueError):
        return None
    if len(blob) < 32 or len(blob) % 16 != 0:
        return None
    iv, ct = blob[:16], blob[16:]
    try:
        data = unpad(AES.new(SESSION_KEY, AES.MODE_CBC, iv).decrypt(ct), 16)
    except ValueError:
        return None

    fields = parse_fields(data)
    role = fields.get("role")
    if role not in ROLES:
        return None
    try:
        if int(fields.get("exp", "0")) < time.time():
            return None
    except ValueError:
        return None
    return {"user": fields.get("u", "unknown"), "role": role}


def require_session():
    sess = open_session()
    if sess is None:
        abort(redirect("/login"))
    return sess

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html", error=None)

    user = request.form.get("username", "")
    pw = request.form.get("password", "")
    if USERS.get(user) != pw:
        return render_template("login.html", error="Invalid staff credentials."), 401

    resp = make_response(redirect("/dashboard"))
    resp.set_cookie("session", seal(user, "guest"), httponly=False, samesite="Lax")
    return resp


@app.route("/logout")
def logout():
    resp = make_response(redirect("/login"))
    resp.delete_cookie("session")
    return resp
